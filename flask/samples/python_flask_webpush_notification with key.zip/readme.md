# Documentation

* Follow the article:
* https://raturi.in/blog/webpush-notification-using-python-and-flask/
